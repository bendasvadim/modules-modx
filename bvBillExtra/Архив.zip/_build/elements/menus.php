<?php

return [
    'modextra' => [
        'description' => 'modextra_menu_desc',
        'action' => 'home',
        //'icon' => '<i class="icon icon-large icon-modx"></i>',
    ],
];