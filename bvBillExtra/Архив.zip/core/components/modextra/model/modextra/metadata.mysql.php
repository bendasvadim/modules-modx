<?php

$xpdo_meta_map = array (
    'xPDOSimpleObject' =>
        array (
            0 => 'modExtraUserBalance',
            1 => 'modExtraUserTransaction',
            2 => 'modExtraUserTransactionStatus',
        ),
);